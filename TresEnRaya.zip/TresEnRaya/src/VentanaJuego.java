import javax.swing.JFrame;

public class VentanaJuego extends JFrame {
	
	VentanaJuego()
	{
		this.add(new TableroJuego());
		this.setTitle("Juego - Tres en raya");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
	}

}
