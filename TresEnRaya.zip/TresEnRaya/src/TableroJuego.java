import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Graphics;

import java.util.Random;

public class TableroJuego extends JPanel implements ActionListener
{
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 600;
	Random random;
	final int NUM_ELEMENTS = 9;
	JPanel[] arrayPanels;
	JButton[] arrayButtons;
	
	TableroJuego()
	{
		this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
		this.setBackground(Color.black);
		this.setFocusable(true);
		setLayout(new GridLayout(0, 3, 0, 0));
		
		random = new Random();
		
		arrayPanels = new JPanel[NUM_ELEMENTS];
		arrayButtons = new JButton[NUM_ELEMENTS];
		
		arrayPanels[0] = new JPanel();
		arrayPanels[0].setBackground(Color.WHITE);
		add(arrayPanels[0]);
		
		arrayButtons[0] = new JButton("Cambiar color");
		arrayButtons[0].addActionListener(this);
		arrayPanels[0].add(arrayButtons[0]);
		
		arrayPanels[1] = new JPanel();
		arrayPanels[1].setBackground(Color.WHITE);
		add(arrayPanels[1]);
		
		arrayButtons[1] = new JButton("Cambiar color");
		arrayButtons[1].addActionListener(this);
		arrayPanels[1].add(arrayButtons[1]);
		
		arrayPanels[2] = new JPanel();
		arrayPanels[2].setBackground(Color.WHITE);
		add(arrayPanels[2]);
		
		arrayButtons[2] = new JButton("Cambiar color");
		arrayButtons[2].addActionListener(this);
		arrayPanels[2].add(arrayButtons[2]);
		
		arrayPanels[3] = new JPanel();
		arrayPanels[3].setBackground(Color.WHITE);
		add(arrayPanels[3]);
		
		arrayButtons[3] = new JButton("Cambiar color");
		arrayButtons[3].addActionListener(this);
		arrayPanels[3].add(arrayButtons[3]);
		
		arrayPanels[4] = new JPanel();
		arrayPanels[4].setBackground(Color.WHITE);
		add(arrayPanels[4]);
		
		arrayButtons[4] = new JButton("Cambiar color");
		arrayButtons[4].addActionListener(this);
		arrayPanels[4].add(arrayButtons[4]);
		
		arrayPanels[5] = new JPanel();
		arrayPanels[5].setBackground(Color.WHITE);
		add(arrayPanels[5]);
		
		arrayButtons[5] = new JButton("Cambiar color");
		arrayButtons[5].addActionListener(this);
		arrayPanels[5].add(arrayButtons[5]);
		
		arrayPanels[6] = new JPanel();
		arrayPanels[6].setBackground(Color.WHITE);
		add(arrayPanels[6]);
		
		arrayButtons[6] = new JButton("Cambiar color");
		arrayButtons[6].addActionListener(this);
		arrayPanels[6].add(arrayButtons[6]);
		
		arrayPanels[7] = new JPanel();
		arrayPanels[7].setBackground(Color.WHITE);
		add(arrayPanels[7]);
		
		arrayButtons[7] = new JButton("Cambiar color");
		arrayButtons[7].addActionListener(this);
		arrayPanels[7].add(arrayButtons[7]);
		
		arrayPanels[8] = new JPanel();
		arrayPanels[8].setBackground(Color.WHITE);
		add(arrayPanels[8]);
		
		arrayButtons[8] = new JButton("Cambiar color");
		arrayButtons[8].addActionListener(this);
		arrayPanels[8].add(arrayButtons[8]);
	}
	
	public void checkEndGame()
	{
		Color col1 = arrayPanels[0].getBackground();
		Color col2 = arrayPanels[1].getBackground();
		Color col3 = arrayPanels[2].getBackground();
		Color col4 = arrayPanels[3].getBackground();
		Color col5 = arrayPanels[4].getBackground();
		Color col6 = arrayPanels[5].getBackground();
		Color col7 = arrayPanels[6].getBackground();
		Color col8 = arrayPanels[7].getBackground();
		Color col9 = arrayPanels[8].getBackground();
		
		if (!col1.equals(Color.WHITE) && col1.equals(col2) && col2.equals(col3))
		{
			if (col1.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col1.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col1.equals(Color.WHITE) && col1.equals(col4) && col4.equals(col7))
		{
			if (col1.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col1.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col3.equals(Color.WHITE) && col3.equals(col6) && col6.equals(col9))
		{
			if (col3.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col3.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col7.equals(Color.WHITE) && col7.equals(col8) && col8.equals(col9))
		{
			if (col7.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col7.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col4.equals(Color.WHITE) && col4.equals(col5) && col5.equals(col6))
		{
			if (col4.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col4.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col2.equals(Color.WHITE) && col2.equals(col5) && col5.equals(col8))
		{
			if (col2.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col2.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col1.equals(Color.WHITE) && col1.equals(col5) && col5.equals(col9))
		{
			if (col1.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col1.equals(Color.RED))
			{
				gameOver(false);
			}
		}
		if (!col3.equals(Color.WHITE) && col3.equals(col5) && col5.equals(col7))
		{
			if (col3.equals(Color.BLUE))
			{
				gameOver(true);
			}
			else if (col3.equals(Color.RED))
			{
				gameOver(false);
			}
		}
	}
	
	public void gameOver(boolean usuarioGano)
	{
		for (int i = 0; i < this.NUM_ELEMENTS; i++)
		{
			if (arrayButtons[i]!=null)
			{
				arrayButtons[i].setVisible(false);
			}
		}
		if (usuarioGano == true)
		{
			for (int i = 0; i < arrayPanels.length; i++)
			{
				arrayPanels[i].setBackground(Color.BLUE);
			}
		}
		else if (usuarioGano == false)
		{
			for (int i = 0; i < arrayPanels.length; i++)
			{
				arrayPanels[i].setBackground(Color.RED);
			}
		}
	}
	
	public void turnoMaquina()
	{
		boolean rellenoMaquina = false;
		while(!rellenoMaquina)
		{
			int rndNum = random.nextInt(9);
			JPanel panel = arrayPanels[rndNum];
			JButton button = arrayButtons[rndNum];
			if (panel.getBackground().equals(Color.WHITE))
			{
				button.setVisible(false);
				panel.setBackground(Color.RED);
				rellenoMaquina = true;
			}
		}
	}
	
	public void colorear(ActionEvent e)
	{
		if (e.getSource() == arrayButtons[0])
		{
			arrayButtons[0].setVisible(false);
			arrayPanels[0].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[1])
		{
			arrayButtons[1].setVisible(false);
			arrayPanels[1].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[2])
		{
			arrayButtons[2].setVisible(false);
			arrayPanels[2].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[3])
		{
			arrayButtons[3].setVisible(false);
			arrayPanels[3].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[4])
		{
			arrayButtons[4].setVisible(false);
			arrayPanels[4].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[5])
		{
			arrayButtons[5].setVisible(false);
			arrayPanels[5].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[6])
		{
			arrayButtons[6].setVisible(false);
			arrayPanels[6].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[7])
		{
			arrayButtons[7].setVisible(false);
			arrayPanels[7].setBackground(Color.BLUE);
		}
		if (e.getSource() == arrayButtons[8])
		{
			arrayButtons[8].setVisible(false);
			arrayPanels[8].setBackground(Color.BLUE);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		colorear(e);
		turnoMaquina();
		checkEndGame();
	}
}
