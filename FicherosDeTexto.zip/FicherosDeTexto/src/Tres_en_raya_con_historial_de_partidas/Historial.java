package Tres_en_raya_con_historial_de_partidas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;

public class Historial extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	BufferedReader reader;
	String[] datosHistorial;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Historial dialog = new Historial();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Historial() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		
		// Se almacena el número de líneas con contenido (con un resultado)
		// Esto se utilizará en el siguiente método
		int numDatos = contarDatos();
		// Primero se recogen los Strings de los resultados
		recogerDatos(numDatos);
		
		// Se controla si el fichero está vacío (no se ha finalizado ninguna partida) o no:
		if (numDatos > 0 && this.datosHistorial != null)
		{
			// Si el fichero tenía algún contenido, sencillamente se crea una JList con los datos almacenados anteriormente:
			JList list = new JList(this.datosHistorial);
			contentPanel.add(list);
			list.setVisibleRowCount(10);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			// Se mete la lista en un ScrollPane para que se pueda hacer scroll:
			JScrollPane scrollPane = new JScrollPane(list);
			scrollPane.setPreferredSize(new Dimension(200, 200));
			contentPanel.add(scrollPane);
		}
		else
		{
			JLabel label = new JLabel("No hay partidas registradas");
			contentPanel.add(label);
		}
		this.setVisible(true);
	}
	
	public void recogerDatos(int numDatos)
	{
		// Se van a almacenar los Strings de los resultados en this.datosHistorial
		this.datosHistorial = new String[numDatos];
		try {
			this.reader = new BufferedReader(new FileReader("historialResultados.txt"));
			String linea;
			// Por cada dato se espera una línea con contenido que se va guardando en el vector de Strings
			// Aquí nos es muy útil el número de datos que se ha registrado anteriormente
			for (int i = 0; i < numDatos;)
			if ((linea = reader.readLine()).matches(""))
			{
			}
			else
			{
				this.datosHistorial[i] = linea;
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int contarDatos()
	{
		int contador = 0;
		try {
			this.reader = new BufferedReader(new FileReader("historialResultados.txt"));
			String linea;
			while ((linea = reader.readLine()) != null)
			{
				// Se cuentan sólo las líneas con contenido:
				if ((linea = reader.readLine()).matches(""))
				{
				}
				else
				{
					contador++;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contador;
	}

}
