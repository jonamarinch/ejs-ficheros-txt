package Tres_en_raya_con_historial_de_partidas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;

public class Historial extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	BufferedReader reader;
	String[] datosHistorial;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Historial dialog = new Historial();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Historial() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		
		int numDatos = contarDatos();
		recogerDatos(numDatos);
		
		if (numDatos > 0 && this.datosHistorial != null)
		{
			JList list = new JList(this.datosHistorial);
			contentPanel.add(list);
			list.setVisibleRowCount(10);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			JScrollPane scrollPane = new JScrollPane(list);
			scrollPane.setPreferredSize(new Dimension(200, 200));
			contentPanel.add(scrollPane);
		}
		else
		{
			JLabel label = new JLabel("No hay partidas registradas");
			contentPanel.add(label);
		}
		this.setVisible(true);
	}
	
	public void recogerDatos(int numDatos)
	{
		this.datosHistorial = new String[numDatos];
		try {
			this.reader = new BufferedReader(new FileReader("historialResultados.txt"));
			String linea;
			for (int i = 0; i < numDatos;)
			if ((linea = reader.readLine()).matches(""))
			{
			}
			else
			{
				this.datosHistorial[i] = linea;
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int contarDatos()
	{
		int contador = 0;
		try {
			this.reader = new BufferedReader(new FileReader("historialResultados.txt"));
			String linea;
			while ((linea = reader.readLine()) != null)
			{
				if ((linea = reader.readLine()).matches(""))
				{
				}
				else
				{
					contador++;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contador;
	}

}
