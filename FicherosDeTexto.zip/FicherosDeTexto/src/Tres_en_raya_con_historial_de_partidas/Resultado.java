package Tres_en_raya_con_historial_de_partidas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Resultado extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	BufferedWriter writer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Resultado dialog = new Resultado("USUARIO (AZULES) GANAN");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Resultado(String resultado) {
		setBounds(100, 100, 275, 300/2);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		// Se registra el resultado recibido en el fichero:
		this.registrarResultado(resultado);
		// Y sencillamente hay un label que informa del resultado (básicamente muestra un String que
		// se ha pasado por parámetro)
		JLabel lblNewLabel = new JLabel("Resultado: " + resultado);
		contentPanel.add(lblNewLabel);
		
		this.setVisible(true);
	}
	
	public void registrarResultado(String resultado)
	{
		try {
			this.writer = new BufferedWriter(new FileWriter("historialResultados.txt", true));
			// Se almacena con espacios. Esto se usará para distinguir un resultado de otro
			// Y así poder contarlos y almacenarlos de forma separada:
			writer.write("\n"+resultado+"\n");
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
