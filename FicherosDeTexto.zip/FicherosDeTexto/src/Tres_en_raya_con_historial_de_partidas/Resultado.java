package Tres_en_raya_con_historial_de_partidas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Resultado extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	BufferedWriter writer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Resultado dialog = new Resultado("USUARIO (AZULES) GANAN");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Resultado(String resultado) {
		setBounds(100, 100, 275, 300/2);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		this.registrarResultado(resultado);
		JLabel lblNewLabel = new JLabel("Resultado: " + resultado);
		contentPanel.add(lblNewLabel);
		
		this.setVisible(true);
	}
	
	public void registrarResultado(String resultado)
	{
		try {
			this.writer = new BufferedWriter(new FileWriter("historialResultados.txt", true));
			writer.write("\n"+resultado+"\n");
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
