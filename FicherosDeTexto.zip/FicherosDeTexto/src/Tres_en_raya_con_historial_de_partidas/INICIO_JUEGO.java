package Tres_en_raya_con_historial_de_partidas;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class INICIO_JUEGO {

	/*
	 * PARA INICIAR EL PROGRAMA:
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MenuInicio();
		
		// Esto es para que al iniciar el programa siempre se limpie el texto
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter("historialResultados.txt", false));
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
