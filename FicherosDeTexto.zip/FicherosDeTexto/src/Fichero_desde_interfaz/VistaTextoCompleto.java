package Fichero_desde_interfaz;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.DropMode;

public class VistaTextoCompleto extends JDialog implements ActionListener{

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	JButton okButton;
	JButton cancelButton;
	String texto;
	JTextArea textArea;
	BufferedWriter writer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			VistaTextoCompleto dialog = new VistaTextoCompleto(propietario, "Texto Completo", "Hey");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public VistaTextoCompleto(JFrame propietario, String titulo, String texto) {
		setBounds(100*2, 100*2, 450*2, 300*2);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			textArea = new JTextArea();
			textArea.setBounds(67, 89, 750, 350);
			this.texto = texto;
			textArea.setText(texto);
			JScrollPane scrollPane = new JScrollPane(textArea);
			getContentPane().add(scrollPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("Guardar texto");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(this);
			}
			{
				cancelButton = new JButton("Cancelar");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
				cancelButton.addActionListener(this);
			}
		}
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(okButton))
		{
			String texto = textArea.getText();
			try {
				this.writer = new BufferedWriter(new FileWriter("ficheroInterfaz.txt", false));
				String textoAdd = "";
				textoAdd = textArea.getText();
				File fichInt = new File("ficheroInterfaz.txt");
				writer.write(textoAdd);
				writer.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if (e.getSource().equals(cancelButton))
		{
			textArea.setText(texto);
		}
	}

}
