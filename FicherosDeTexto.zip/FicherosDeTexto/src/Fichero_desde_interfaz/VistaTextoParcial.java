package Fichero_desde_interfaz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;

public class VistaTextoParcial extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	JButton btnAnadir;
	JButton btnTextoCompleto;
	JTextArea txtrTextoAGuardar;
	File fichero;
	BufferedWriter writer;
	BufferedReader reader;
	String textoAdd;
	String textoGet;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VistaTextoParcial frame = new VistaTextoParcial();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VistaTextoParcial() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100*2, 100*2, 450*2, 300*2);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtrTextoAGuardar = new JTextArea();
		txtrTextoAGuardar.setText("Texto a guardar");
		txtrTextoAGuardar.setBounds(192, 30, 500, 250);
		contentPane.add(txtrTextoAGuardar);
		
		btnAnadir = new JButton("Añadir al texto");
		btnAnadir.setBounds(367, 355, 150, 50);
		contentPane.add(btnAnadir);
		btnAnadir.addActionListener(this);
		
		btnTextoCompleto = new JButton("Ver texto completo");
		btnTextoCompleto.setBounds(367, 426, 150, 50);
		contentPane.add(btnTextoCompleto);
		btnTextoCompleto.addActionListener(this);
		
		try {
			this.writer = new BufferedWriter(new FileWriter("ficheroInterfaz.txt", false));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void actualizarTexto()
	{
		try {
			this.reader = new BufferedReader(new FileReader("ficheroInterfaz.txt"));
			String texto = "";
			String linea = "";
			int cont = 0;
			while ((linea = this.reader.readLine()) != null)
			{
				if (cont == 0)
				{
					texto = linea;
				}
				else
				{
					texto += "\n"+linea;	
				}
				cont++;
			}
			this.textoGet = texto;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(btnAnadir))
		{
			try {
				this.writer = new BufferedWriter(new FileWriter("ficheroInterfaz.txt", true));
				this.textoAdd = "";
				this.textoAdd = txtrTextoAGuardar.getText();
				File fichInt = new File("ficheroInterfaz.txt");
				if (fichInt.length()==0)
				{
					writer.write(this.textoAdd);
				}
				else
				{
					writer.write("\n\n" + this.textoAdd);
				}
				writer.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if (e.getSource().equals(btnTextoCompleto))
		{
			actualizarTexto();
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			VistaTextoCompleto txtCompl = new VistaTextoCompleto(propietario, "Texto Completo", this.textoGet);
		}
	}
	
}
