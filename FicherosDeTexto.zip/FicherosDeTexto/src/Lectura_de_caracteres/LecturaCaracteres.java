package Lectura_de_caracteres;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class LecturaCaracteres {
	
	BufferedWriter writer;
	BufferedReader reader;
	String texto;
	
	public static void main(String[] args)
	{
		LecturaCaracteres lectura = new LecturaCaracteres();
		lectura.escribir();
		System.out.println("En el fichero se encuentra este número de caracteres numéricos: " + lectura.contarCarNum());
		lectura.copiar();
		lectura.pegar();
	}
	
	public void escribir()
	{
		try {
			this.writer = new BufferedWriter(new FileWriter("output.txt"));
			writer.write("Lorem ipsum 1.");
			writer.write("\n2a línea.");
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int contarCarNum()
	{
		int numCar = 0;
		try {
			this.reader = new BufferedReader(new FileReader("output.txt"));
			String linea;
			while ((linea = reader.readLine()) != null)
			{
				for (int i = 0; i < linea.length(); i++)
				{
					String car = linea.charAt(i)+"";
					if (car.matches("\\d"))
					{
						numCar++;
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return numCar;
	}
	
	public void copiar()
	{
		try {
			this.reader = new BufferedReader(new FileReader("output.txt"));
			String linea;
			int cont = 0;
			while ((linea = reader.readLine()) != null)
			{
				if (cont == 0)
				{
					this.texto = linea;
				}
				else
				{
					this.texto += "\n"+linea;	
				}
				cont++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void pegar()
	{
		try {
			this.writer = new BufferedWriter(new FileWriter("output2.txt"));
			writer.write(this.texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
