package Lectura_de_caracteres;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class LecturaCaracteres {
	
	BufferedWriter writer;
	BufferedReader reader;
	String texto;
	
	/*
	 * PARA INICIAR EL PROGRAMA:
	 */
	public static void main(String[] args)
	{
		LecturaCaracteres lectura = new LecturaCaracteres();
		lectura.escribir();
		System.out.println("En el fichero se encuentra este número de caracteres numéricos: " + lectura.contarCarNum());
		lectura.copiar();
		lectura.pegar();
	}
	
	public void escribir()
	{
		try {
			// Se sobreescribirá si es que ya existe
			this.writer = new BufferedWriter(new FileWriter("output.txt"));
			// Se escriben dos líneas
			writer.write("Lorem ipsum 1.");
			writer.write("\n2a línea.");
			// Se cierra el writer
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int contarCarNum()
	{
		// Se comienza con 0 nums
		int numCar = 0;
		try {
			this.reader = new BufferedReader(new FileReader("output.txt"));
			// Se va guardando línea a línea
			String linea;
			// El bucle termina cuando el archivo ya no tenga contenido
			while ((linea = reader.readLine()) != null)
			{
				// Se recorre la línea
				for (int i = 0; i < linea.length(); i++)
				{
					String car = linea.charAt(i)+"";
					// Si el caracter es un dígito, aumenta el contador
					if (car.matches("\\d"))
					{
						numCar++;
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return numCar;
	}
	
	public void copiar()
	{
		try {
			this.reader = new BufferedReader(new FileReader("output.txt"));
			String linea;
			// El contador nos sirve para distinguir la primera línea del resto
			int cont = 0;
			while ((linea = reader.readLine()) != null)
			{
				// Se comienza por la primera línea asigándola a this.texto
				// El resto de líneas se van agregando con un break
				// El resultado esperado es almacenar todo el contenido en this.texto
				if (cont == 0)
				{
					this.texto = linea;
				}
				else
				{
					this.texto += "\n"+linea;	
				}
				cont++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void pegar()
	{
		try {
			// Para pegar sencillamente escribimos el contenido de this.texto en un archivo distinto
			this.writer = new BufferedWriter(new FileWriter("output2.txt"));
			writer.write(this.texto);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
